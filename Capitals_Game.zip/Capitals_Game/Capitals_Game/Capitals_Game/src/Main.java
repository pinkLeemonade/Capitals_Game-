import Property_Binding.Capital_Game;

public class Main {
    public static void main(String[] args) {
        System.out.println("===================================================");
        System.out.println("  ██████╗     ███        ███╗       ███╗ ███████╗");
        System.out.println(" ██╔════╝   ██═══██╗     ████╗     ╚████ ██╔════╝");
        System.out.println(" ██║  ███╗ ╚ ██████╔╝    ██╔██╗  ╚██╗║██ █████╗");
        System.out.println(" ██║   ██║ ██║     ██    ██║╚██╗██╗  ║██ ██╔══╝");
        System.out.println(" ╚██████╔╝██║       ██║  ██║ ╚████╗  ║██ ███████╗");
        System.out.println("  ╚═════╝ ╚═╝       ╚═╝  ╚═╝  ╚══╝   ╚═╝ ╚══════╝");
        System.out.println("===================================================");
        System.out.println();
        System.out.println("Welcome to the Capitals Game!");
        System.out.println("Here, we have a puzzle that alters a letter in the grid of your choice from lower to upper case");
        System.out.println("Grid sizes 3x3, 3x4, 3x5, " +
                "4x4, 4x5, 4x6, etc." + "N/B: (Rows x Coloumns)");
        System.out.println("<<<<<<<<The Capitals Game>>>>>>>");
        System.out.println();

        // Create an instance of Capitals game
        Capital_Game game = new Capital_Game();

        // Start the game
        game.run();
    }
}
