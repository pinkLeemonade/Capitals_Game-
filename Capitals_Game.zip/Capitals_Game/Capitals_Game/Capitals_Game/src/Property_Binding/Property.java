package Property_Binding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Represents a property that can be observed for changes.
 * @param <T> The type of the property value.
 */
public class Property<T> {
    private T value; // The current value of the property
    private final Object owner; // The owner object of this property
    private final List<PropertyListener<T>> listeners; // List of listeners observing this property
    private T oldValue; // The previous value of the property

    /**
     * Constructs a new Property with an initial value.
     * @param owner The owner object of this property. Once set in the constructor, it remains read-only.
     * @param initialValue The initial value of the property
     */
    public Property(Object owner, T initialValue){
        this.value = initialValue;
        this.oldValue = initialValue;
        this.owner = owner; // The owner object, once set, cannot be modified
        listeners = new ArrayList<>();
    }

    /**
     * Gets the owner object of this property.
     * @return The owner object
     */
    public Object getOwner() {
        return owner;
    }

    /**
     * Gets the current value of the property.
     * @return The current value
     */
    public T get() {
        return value;
    }

    /**
     * Sets a new value for the property.
     * @param newValue The new value to be set
     */
    public void set(T newValue) {
        oldValue = value; // Store the current value as the old value
        value = newValue; // Set the new value
        notifyListeners(); // Notify all listeners about the value change
    }

    /**
     * Adds a listener to observe changes in the property.
     * @param listener The listener to be added
     */
    public void addListener(PropertyListener<T> listener) {
        listeners.add(listener);
    }

    /**
     * Adds multiple listeners to observe changes in the property.
     * @param listeners The listeners to be added
     */
    public void addListeners(PropertyListener<T>... listeners) {
        this.listeners.addAll(Arrays.asList(listeners));
    }

    /**
     * Removes a listener from observing the property.
     * @param listener The listener to be removed
     */
    public void removeListener(PropertyListener<T> listener) {
        listeners.remove(listener);
    }

    /**
     * Notifies all listeners about a change in the property value.
     */
    protected void notifyListeners(){
        for (PropertyListener<T> listener: listeners) {
            listener.valueChanged(this, oldValue, value);
        }
    }
}


