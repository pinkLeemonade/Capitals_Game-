package Property_Binding;
@FunctionalInterface
public interface PropertyListener<T> {
    void valueChanged(Property<T> property, T oldValue, T newValue);
}