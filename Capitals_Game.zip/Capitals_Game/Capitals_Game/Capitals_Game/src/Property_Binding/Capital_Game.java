package Property_Binding;

import Property_Binding.Capital_Game;

import java.util.Random;
import java.util.Scanner;

public class Capital_Game {
    Property<Character>[][] grid;

    // Constructor
    public Capital_Game() {
        // Initialize grid with user-defined dimensions
        grid = new Property[getGridSize("rows")][getGridSize("columns")];

        // Generate random letters for each cell in the grid
        generateLetters();

        // Attach listeners to adjacent cells for each cell in the grid
        for (int x = 0; x < grid.length; x++) {
            for (int i = 0; i < grid[0].length; i++) {
                adjacentListeners(x, i);
            }
        }
        // Display the initial grid
        display();
    }
    // Method to get grid size from user input
    public static int getGridSize(String dimension) {
        boolean firstGame = true;
        Scanner in = new Scanner(System.in);
        int gridSize;

        do {
            if (firstGame) {
                System.out.print("Enter number of " + dimension + ":\n");
                firstGame = false;
            } else {
                System.out.print("Enter a valid number of " + dimension + ":\n");
            }

            while (!in.hasNextInt()) {
                System.out.print("Enter a valid number of " + dimension + ":\n");
                in.next();
            }

            gridSize = in.nextInt();
        } while (gridSize <= 0);

        return gridSize;
    }

    // Method to generate random letters for each cell in the grid
    private void generateLetters() {
        Random randomLetters = new Random();
        String letters = "abcdefghijklmnop";

        for (int j = 0; j < grid.length; j++) {
            for (int i = 0; i < grid[0].length; i++) {
                int newLetterPosition = randomLetters.nextInt(letters.length());
                char newLetter = letters.charAt(newLetterPosition);
                grid[j][i] = new Property<>(this, ((randomLetters.nextInt(2) == 1)
                        ? Character.toUpperCase(newLetter) : newLetter));

                String newOptions = letters.substring(0, newLetterPosition);
                if (newLetterPosition != letters.length() - 1)
                    newOptions = newOptions + letters.substring(newLetterPosition + 1);
                letters = newOptions;
            }
        }
    }

    // Method to attach listeners to adjacent cells for a given cell
    private void adjacentListeners(int j, int i) {
        // Attach listener to the cell above (if exists)
        if ((j - 1) >= 0) {
            int row = j - 1;
            int column = i;
            grid[j][i].addListener((property, oldValue, newValue) -> {
                grid[row][column] = new Property(this,
                        ((grid[row][column].get() == Character.toUpperCase(grid[row][column].get()))
                                ? Character.toLowerCase(grid[row][column].get())
                                : Character.toUpperCase(grid[row][column].get())));
                adjacentListeners(row, column);
            });
        }

        // Attach listener to the cell to the right (if exists)
        if (i + 1 < grid[0].length) {
            int row = j;
            int column = i + 1;
            grid[j][i].addListener((property, oldValue, newValue) -> {
                grid[row][column] = new Property(this,
                        ((grid[row][column].get() == Character.toUpperCase(grid[row][column].get()))
                                ? Character.toLowerCase(grid[row][column].get())
                                : Character.toUpperCase(grid[row][column].get())));
                adjacentListeners(row, column);
            });
        }

        // Attach listener to the cell below (if exists)
        if (j + 1 < grid.length) {
            int row = j + 1;
            int column = i;
            grid[j][i].addListener((property, oldValue, newValue) -> {
                grid[row][column] = new Property(this,
                        ((grid[row][column].get() == Character.toUpperCase(grid[row][column].get()))
                                ? Character.toLowerCase(grid[row][column].get())
                                : Character.toUpperCase(grid[row][column].get())));
                adjacentListeners(row, column);
            });
        }

        // Attach listener to the cell to the left (if exists)
        if (i - 1 >= 0) {
            int row = j;
            int column = i - 1;
            grid[j][i].addListener((property, oldValue, newValue) -> {
                grid[row][column] = new Property(this,
                        ((grid[row][column].get() == Character.toUpperCase(grid[row][column].get()))
                                ? Character.toLowerCase(grid[row][column].get())
                                : Character.toUpperCase(grid[row][column].get())));
                adjacentListeners(row, column);
            });
        }
    }

    // Method to run the game
    public void run() {
        char selected = getLetterSelection();

        // Continue the game until 'x' is entered or a winner is found
        while (selected != 'x') {
            toggleSelected(selected);
            display();

            if (Winner()) {
                selected = 'y';
                break;
            }
            selected = getLetterSelection();
        }

        // Print appropriate message based on game outcome
        if (selected == 'y')
            System.out.println("Congratulations! YOU WIN!");
        else
            System.out.println("Game was cancelled. Better luck next time.");
    }

    // Method to get user input for letter selection
    private char getLetterSelection() {
        String letters = "abcdefghijklmnop";
        Scanner in = new Scanner(System.in);
        char letter;

        do {
            System.out.print("Enter a letter to toggle (switch between 2 options) and 'x' to cancel game: ");
            letter = Character.toLowerCase(in.next().charAt(0));
        } while ((letters.indexOf(letter) == -1) && (letter != 'x'));

        return Character.toLowerCase(letter);
    }

    // Method to display the current state of the grid
    private void display() {
        String divideRow = "+" + "___+".repeat(grid[0].length);

        for (int x = 0; x < grid.length; x++) {
            System.out.println(divideRow);
            for (int i = 0; i < grid[0].length; i++)
                System.out.print("| " + grid[x][i].get() + " ");
            System.out.print("|\n");
        }
        System.out.println(divideRow);
    }

    // Method to toggle the case of the selected letter in the grid
    public void toggleSelected(char selected) {
        for (int x = 0; x < grid.length; x++)
            for (int i = 0; i < grid[0].length; i++) {
                Property<Character> cur = grid[x][i];
                if (Character.toLowerCase(cur.get()) == Character.toLowerCase(selected)) {
                    if (cur.get() == Character.toUpperCase(cur.get()))
                        cur.set(Character.toLowerCase(cur.get()));
                    else
                        cur.set(Character.toUpperCase(cur.get()));
                    return;
                }
            }
    }

    // Method to check if all letters in the grid are in uppercase
    private boolean Winner() {
        for (int j = 0; j < grid.length; j++) {
            for (int i = 0; i < grid[0].length; i++) {
                if (grid[j][i].get() != Character.toUpperCase(grid[j][i].get())) {
                    return false;
                }
            }
        }
        return true;
    }
}